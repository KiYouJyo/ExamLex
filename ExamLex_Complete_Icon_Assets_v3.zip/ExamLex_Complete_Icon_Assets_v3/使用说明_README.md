# ExamLex WinUI 3 / MSIX 图标资产（基于用户指定原母版）

## 先用这两个文件
- `01_ICO/ExamLex.ico`：**真正的多尺寸 Windows ICO 文件**，内含 16、24、32、48、64、128、256 像素图像，可直接用于 `.exe` 图标、安装程序、快捷方式、文件关联。
- `03_WinUI3_MSIX/Assets/`：完整 WinUI 3 / MSIX 包的图片资产文件夹；按项目的 `Package.appxmanifest` 引用。它们都是实际 PNG 图片，不是示例文字或预览。

## 文件夹用途
- `00_Master/ExamLex_Original_Unmodified.png`：用户上传的原版母图，完全不修改。
- `00_Master/ExamLex_OriginalCanvas_CleanAlpha.png`：仅去除少量散点杂色像素后的透明原尺寸图，构图和配色不变。
- `00_Master/ExamLex_Trimmed_Transparent.png`：抠除多余透明画布、保留图像原分辨率内容。
- `00_Master/ExamLex_Master_2048_Transparent.png`：在方形透明画布上居中的分发母版，2048×2048；注意：这是原母版放大排版，不是重新绘制的 SVG。
- `01_ICO/ExamLex.ico`：真正 ICO 容器，7 档图标。
- `02_PNG_Transparent/`：16～2048 像素不同尺寸的独立透明 PNG，可用于 Win32、WinUI、网站 favicon、软件关于页等。
- `03_WinUI3_MSIX/Assets/Square44x44Logo.scale-*.png`：应用列表/应用图标的多倍率资源。
- `03_WinUI3_MSIX/Assets/Square44x44Logo.targetsize-*.png`：精确像素大小的 Windows 程序列表、桌面等图标。
- `03_WinUI3_MSIX/Assets/Square44x44Logo.altform-unplated_targetsize-*.png`：不带系统底板的透明图标变体。
- `03_WinUI3_MSIX/Assets/Square71x71Logo.scale-*.png`：兼容小磁贴资源。
- `03_WinUI3_MSIX/Assets/Square150x150Logo.scale-*.png`：中等磁贴/包视觉资产。
- `03_WinUI3_MSIX/Assets/Square310x310Logo.scale-*.png`：大方形磁贴/包视觉资产。
- `03_WinUI3_MSIX/Assets/Wide310x150Logo.scale-*.png`：宽磁贴资源。
- `03_WinUI3_MSIX/Assets/StoreLogo.scale-*.png`：应用包清单的 StoreLogo 资源，与商店页面宣传截图不是同一种文件。
- `03_WinUI3_MSIX/Assets/SplashScreen.scale-*.png`：应用包启动屏幕视觉资源。
- `04_Store_Icons/`：额外准备的 300、512、1024、1080 像素品牌图；适合作为应用商店图标素材，但商店后台应以当前上传界面要求为准。
- `05_Splash/`：透明及浅色背景的启动图；浅色背景仅为可选版本，不影响原图透明母版。
- `06_Previews/`：各文件视觉核验图。

## 接入建议
1. 若只是 Windows `.exe` 图标，请先使用 `01_ICO/ExamLex.ico`。
2. 如果你的 WinUI 3 项目使用 MSIX，请将 `03_WinUI3_MSIX/Assets/` 文件复制至工程 `Assets/`，保持文件名不变。
3. 在 `Package.appxmanifest` 的图形编辑器 Visual Assets（或对应 XML）中设置 `Square44x44Logo.png`、`Square150x150Logo.png`、`StoreLogo.png`、`Wide310x150Logo.png`、`Square310x310Logo.png`、`SplashScreen.png` 这些逻辑资产名称。实际加载时，Windows 将选择 `.scale-200.png` 等匹配资源。
4. **本包提供的是图标和启动图，不包含真实应用截图。** 商店上架的应用截图需从 ExamLex 软件实际界面截取。
5. 对低分辨率图标建议实机查看：本包尽量完整保留原五张亚克力卡片，不自行给母版增添黑色轮廓或四角厚边框。

## 输出来源声明
所有正式图标基于用户当轮上传的 `未标题-2.png` 直接导出，未重新生成构图，也未改变母版的卡片数量、配色或透明玻璃质感。对母图仅做了少量边缘杂点过滤、居中留白和尺寸转换。
